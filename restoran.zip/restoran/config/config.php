<?php

    define("HOST", "localhost");
    define("DBNAME", "restoran");
    define("USER", "root");
    define("PASS", "");